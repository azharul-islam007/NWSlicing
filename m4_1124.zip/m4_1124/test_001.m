network_model_dl_demo_f();
network_model_ul_demo_f();

