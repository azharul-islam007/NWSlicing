classdef Rsu_c < UE_c % The RSU along the highway

    properties

    end

    methods
        function self = Rsu_c(ueId_i, x_i, y_i, z_i)
            self@UE_c(ueId_i, x_i, y_i, z_i);
        end
    end

end